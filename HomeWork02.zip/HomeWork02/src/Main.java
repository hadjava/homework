public class Main {
    public static void main(String[] args) {
        System.out.println("Jon Quotermein");
        System.out.println("Age 31");
        System.out.println("Height 195");
        System.out.println("");
        System.out.println("Fred Simpson");
        System.out.println("Age 39");
        System.out.println("Height 170");
        System.out.println("");
        System.out.println("Mike Stenford");
        System.out.println("Age 55");
        System.out.println("Height 180");
        System.out.println("");
        System.out.printf("'%5.2f'%n",3.222);
        System.out.printf("'%5.2f'%n",4.333);
        System.out.printf("'%5.2f'%n",5.444);


        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");
        System.out.println("|        |");

        System.out.println("Задание выполнено, но в пункте б не получается отделить числа пробелами");







    }
}