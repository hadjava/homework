import java.sql.SQLOutput;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        //Проект 2
        //Компьютер генерирует три произвольных числа из диапазона от 0 до 999.
        //Найдите сумму чисел, выведите на экран.
        //Найдите произведение чисел, выведите на экран.

        Random random = new Random();

        int num1 = random.nextInt(999);
        int num2 = random.nextInt(999);
        int num3 = random.nextInt(999);

        int summa = num1 + num2 + num3;
        int proizvod = num1 * num2 * num3;

        //Выводим результат
        System.out.println("Сумма: " + summa);
        System.out.println("Произведение: " + proizvod);


    }
}