public class Main {
    public static void main(String[] args) {
        //Проект 3
        //1 Создайте строковую переменную, положите в неё "I study Basic Java!" или любое другое предложение
        //2 Распечатайте первый символ строки. Используем метод String.charAt().
        //3 Распечатайте последний символ строки.
        //4 Проверить, содержит ли Ваша строка подстроку “Java”. Используем метод String.contains(). Вывести в консоль результат проверки
        //5 Заменить все символы "а" на "о". Вывести в консоль результат
        //6 Преобразуйте строку к верхнему регистру. Выведите в консоль
        //7 Преобразуйте строку к нижнему регистру. Выведите в консоль
        //8 Вырезать подстроку "Java" c помощью метода String.substring().

        String a = "I study Basic Java!";
        // Выводим первый и последний символ
        System.out.println("I study Basic Java!".charAt( 0 ));
        System.out.println("I study Basic Java!".charAt( 18 ));

        //4.Проверить, содержит ли Ваша строка подстроку “Java”.

        boolean contains = a.contains( "Java" );
        System.out.println("Строка содержит 'Java': " + contains);

        //5. Заменить все символы "а" на "о". Вывести в консоль результат
        String replacedStr = a.replace('a', 'o');
        System.out.println("Заменили символы: " + replacedStr);

        //6. Преобразуйте строку к верхнему регистру. Выведите в консоль
        String uppStr = a.toUpperCase();
        System.out.println("Подняли к верхнему регистру: " + uppStr);

        //7. Преобразуйте строку к нижнему регистру. Выведите в консоль
        String lowStr = a.toLowerCase();
        System.out.println("Lower case string: " + lowStr);

        //8. Вырезать подстроку "Java" c помощью метода String.substring().
        String substring = a.substring(a.indexOf("Java"), a.indexOf("Java") + "Java".length());
        System.out.println("Substring: " + substring);








    }
}