import com.sun.security.jgss.GSSUtil;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*
        1 уровень сложности: Проект 1
        1 Пользователь вводит трёхзначное число.
        2 Программа должна вывести на экран все цифры этого числа.
         Какждая цифра должна быть выведена в отдельной строчке.
        */

        //Класс Scanner берет данные из консоли
        Scanner scr = new Scanner( System.in );
        System.out.println("Введите трехзначное число, пожалуйста:  " );
        int number = scr.nextInt();
        System.out.println("Ваше число: " + number);

        //Пример как можно разбить число на 3 цифры:
        // int a = 123 / 100 = 1
        //int b = 123 / 10 % 10 = 2
        //int c = 123 % 100

        int digit1 = number /100;
        int digit2 = number /10 % 10;
        int digit3 = number % 10;

        // Выводим на экран результат

        System.out.println(digit1);
        System.out.println(digit2);
        System.out.println(digit3);



    }
}