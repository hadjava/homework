public class Main {
    public static void main(String[] args) {
        //Проект 1
        //1 Создайте переменную byte b = 1;
        //2 Присвойте её значение новым переменным типов short, int, long, double.
        //3 Выведите значение новых переменных в консоль.

        byte b1 = 1;
        short s1 = b1;
        int i1 = s1;
        long l1 = i1;
        double d1 = l1;
        //Выводим в консоль
        System.out.println( "Выводим byte: " + b1);
        System.out.println( "Выводим short: " +s1);
        System.out.println( "Выводим int: " + i1);
        System.out.println( "Выводим long: " + l1);
        System.out.println( "Выводим double: " + d1);
    }
}