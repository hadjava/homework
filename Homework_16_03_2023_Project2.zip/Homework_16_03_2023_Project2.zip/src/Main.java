public class Main {
    public static void main(String[] args) {
        //Проект 2
        //1 Создайте переменную long lo = 1000L;
        //2 Присвойте её значение новым переменным типов byte, short, int, double.
        //3 Выведите значение новых переменных в консоль.

        long lo = 1000L;
        byte by = (byte) lo;
        short sh = (short) lo;
        int in = (int) lo;
        double d = (double) lo;


//Выводим
        System.out.println( "Byte: " + by );
        System.out.println( "Short: " + sh );
        System.out.println( "Int: " + in );
        System.out.println( "Double: " + d );
    }
}